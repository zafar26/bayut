import Navbar from '../../components/Navbar/Navbar';

const CustomPage = () => {
    return (
        <>
            <Navbar />
        </>
    );
};
export default CustomPage;
