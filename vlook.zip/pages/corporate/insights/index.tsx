const Insights = () => {
    return <div>Insights</div>;
};

export default Insights;
